<?php
require_once __DIR__ . '/../config/Database.php';

class Movie extends Database {

    public function __construct() {
        parent::__construct(); // Call parent constructor (Database)
        $this->connect();      // Establish connection automatically
    }

    // Function to add a new movie to the database
    public function addMovie($title, $director, $genre, $releaseYear, $durationMinutes, $rating) {
        try {
            $stmt = $this->conn->prepare("INSERT INTO movies (title, director, genre, release_year, duration_minutes, rating) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssiis", $title, $director, $genre, $releaseYear, $durationMinutes, $rating);
            return $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            // e.g. duplicate value in a UNIQUE column
            return false;
        }
    }

    // Function to get all movies from the database
    public function getAllMovies() {
        $stmt = $this->conn->prepare("SELECT * FROM movies");
        $stmt->execute();
        return $stmt->get_result();
    }

    // Function to get a single movie by ID
    public function getMovieById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM movies WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // Function to update a movie's information
    public function updateMovie($id, $title, $director, $genre, $releaseYear, $durationMinutes, $rating) {
        try {
            $stmt = $this->conn->prepare("UPDATE movies SET title = ?, director = ?, genre = ?, release_year = ?, duration_minutes = ?, rating = ? WHERE id = ?");
            $stmt->bind_param("sssiisi", $title, $director, $genre, $releaseYear, $durationMinutes, $rating, $id);
            return $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            return false;
        }
    }

    // Function to delete a movie from the database
    public function deleteMovie($id) {
        $stmt = $this->conn->prepare("DELETE FROM movies WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
