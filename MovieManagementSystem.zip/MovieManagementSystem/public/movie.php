<?php

// Include the Movie class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/Movie.php means go up one directory,
// then locate the Movie.php file inside the classes folder.
include_once __DIR__ . '/../classes/Movie.php';

// Create an object (instance) of the Movie class.
// This object will be used to call the addMovie() method.
$movie = new Movie();

// Initialize an empty message variable.
// This will store the result of the movie registration process.
$message = '';

// Show a message passed from the edit/delete pages (if any).
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

// Check whether the submitted request uses the POST method.
// Also check whether all required form fields are present
// in the $_POST array.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['title'], $_POST['director'], $_POST['genre'], $_POST['releaseYear'], $_POST['durationMinutes'], $_POST['rating'])) {

    // Retrieve the movie's title.
    $title = $_POST['title'];

    // Retrieve the movie's director.
    $director = $_POST['director'];

    // Retrieve the movie's genre.
    $genre = $_POST['genre'];

    // Retrieve the movie's release year.
    $releaseYear = $_POST['releaseYear'];

    // Retrieve the movie's duration (minutes).
    $durationMinutes = $_POST['durationMinutes'];

    // Retrieve the movie's rating.
    $rating = $_POST['rating'];

    // Call the addMovie() method of the Movie object.
    // It returns true if the movie is added successfully,
    // or false if the operation fails.
    if ($movie->addMovie($title, $director, $genre, $releaseYear, $durationMinutes, $rating)) {
        $message = "Movie added successfully!";
    } else {
        $message = "Error adding movie.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Movie Management System</h1>
        <p class="text-center">Movie Page</p>

        <div class="text-center">
            <a href="index.php" class="btn btn-primary">Dashboard</a>
            <a href="#" class="btn btn-primary">Movies</a>
        </div>

        <div class="row mt-4">
            <div class="col-md-4 mx-auto">
                <!-- Feedback message after operation -->
                <?php if ($message) echo "<div class='alert alert-info'>$message</div>"; ?>

                <h2 class="text-center mb-4">Add New Movie</h2>
                <form method="POST" action="movie.php">
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" class="form-control" name="title" placeholder="Enter movie title" required>
                    </div>
                    <div class="form-group">
                        <label>Director</label>
                        <input type="text" class="form-control" name="director" placeholder="Enter director name" required>
                    </div>
                    <div class="form-group">
                        <label>Genre</label>
                        <input type="text" class="form-control" name="genre" placeholder="Enter genre" required>
                    </div>
                    <div class="form-group">
                        <label>Release Year</label>
                        <input type="number" class="form-control" name="releaseYear" step="1" placeholder="Enter release year" required>
                    </div>
                    <div class="form-group">
                        <label>Duration (minutes)</label>
                        <input type="number" class="form-control" name="durationMinutes" step="1" placeholder="Enter duration in minutes" required>
                    </div>
                    <div class="form-group">
                        <label>Rating</label>
                        <select class="form-control" name="rating" required>
                            <option value="G">G</option>
                            <option value="PG">PG</option>
                            <option value="PG-13">PG-13</option>
                            <option value="R">R</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </div>
            <div class="col-md-8 mx-auto">
                <h2 class="text-center mb-4">Movie List</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Director</th>
                            <th>Genre</th>
                            <th>Release Year</th>
                            <th>Duration (minutes)</th>
                            <th>Rating</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        $movies = $movie->getAllMovies();
                        while ($row = $movies->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['director']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['genre']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['release_year']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['duration_minutes']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['rating']) . "</td>";
                            echo "<td>
                                    <a href='edit_movie.php?id=" . $row['id'] . "' class='btn btn-primary btn-sm'>Edit</a>
                                    <a href='delete_movie.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick=\"return confirm('Delete this movie?');\">Delete</a>
                                 </td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
