<?php
// Include the Movie class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/Movie.php means go up one directory,
// then locate the Movie.php file inside the classes folder.
include_once __DIR__ . '/../classes/Movie.php';
$movie = new Movie();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['title'], $_POST['director'], $_POST['genre'], $_POST['releaseYear'], $_POST['durationMinutes'], $_POST['rating'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $director = $_POST['director'];
    $genre = $_POST['genre'];
    $releaseYear = $_POST['releaseYear'];
    $durationMinutes = $_POST['durationMinutes'];
    $rating = $_POST['rating'];

    // Update existing movie
    if ($movie->updateMovie($id, $title, $director, $genre, $releaseYear, $durationMinutes, $rating)) {
        header("Location: movie.php?message=" . urlencode("Movie updated successfully"));
        exit();
    } else {
        header("Location: movie.php?message=" . urlencode("Error updating movie"));
        exit();
    }
}

// Load the movie to edit
$record = $movie->getMovieById(isset($_GET['id']) ? $_GET['id'] : null);
if (!$record) {
    header("Location: movie.php?message=" . urlencode("Movie not found"));
    exit();
}

// Pre-fill the form fields with the movie's data for editing
$id = $record['id'];
        $title = $record['title'];
        $director = $record['director'];
        $genre = $record['genre'];
        $releaseYear = $record['release_year'];
        $durationMinutes = $record['duration_minutes'];
        $rating = $record['rating'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Movie Management System</h1>
        <h2 class="text-center mb-4">Edit Movie</h2>
        <div class="col-md-5 mx-auto">
            <form method="POST" action="edit_movie.php">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
            <div class="form-group">
                <label>Title</label>
                <input type="text" class="form-control" name="title" value="<?php echo htmlspecialchars($title); ?>" placeholder="Enter movie title" required>
            </div>
            <div class="form-group">
                <label>Director</label>
                <input type="text" class="form-control" name="director" value="<?php echo htmlspecialchars($director); ?>" placeholder="Enter director name" required>
            </div>
            <div class="form-group">
                <label>Genre</label>
                <input type="text" class="form-control" name="genre" value="<?php echo htmlspecialchars($genre); ?>" placeholder="Enter genre" required>
            </div>
            <div class="form-group">
                <label>Release Year</label>
                <input type="number" class="form-control" name="releaseYear" value="<?php echo htmlspecialchars($releaseYear); ?>" step="1" placeholder="Enter release year" required>
            </div>
            <div class="form-group">
                <label>Duration (minutes)</label>
                <input type="number" class="form-control" name="durationMinutes" value="<?php echo htmlspecialchars($durationMinutes); ?>" step="1" placeholder="Enter duration in minutes" required>
            </div>
            <div class="form-group">
                <label>Rating</label>
                <select class="form-control" name="rating" required>
                    <option value="G" <?php echo ($rating === 'G') ? 'selected' : ''; ?>>G</option>
                    <option value="PG" <?php echo ($rating === 'PG') ? 'selected' : ''; ?>>PG</option>
                    <option value="PG-13" <?php echo ($rating === 'PG-13') ? 'selected' : ''; ?>>PG-13</option>
                    <option value="R" <?php echo ($rating === 'R') ? 'selected' : ''; ?>>R</option>
                </select>
            </div>
                <button type="submit" class="btn btn-success">Submit</button>
                <a href="movie.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
