<?php
// Include the Movie class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/Movie.php means go up one directory,
// then locate the Movie.php file inside the classes folder.
include_once __DIR__ . '/../classes/Movie.php';
$movie = new Movie();

$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($id) {
    // Delete the movie with the given ID
    if ($movie->deleteMovie($id)) {
        header("Location: movie.php?message=" . urlencode("Movie deleted successfully"));
        exit();
    } else {
        echo "Error deleting movie.";
    }
} else {
    echo "Invalid movie ID.";
}

?>
