<?php

// Include the House class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/House.php means go up one directory,
// then locate the House.php file inside the classes folder.
include_once __DIR__ . '/../classes/House.php';

// Create an object (instance) of the House class.
// This object will be used to call the addHouse() method.
$house = new House();

// Initialize an empty message variable.
// This will store the result of the house registration process.
$message = '';

// Show a message passed from the edit/delete pages (if any).
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

// Check whether the submitted request uses the POST method.
// Also check whether all required form fields are present
// in the $_POST array.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['listingNumber'], $_POST['address'], $_POST['city'], $_POST['price'], $_POST['bedrooms'], $_POST['bathrooms'])) {

    // Retrieve the house's listing number.
    $listingNumber = $_POST['listingNumber'];

    // Retrieve the house's address.
    $address = $_POST['address'];

    // Retrieve the house's city.
    $city = $_POST['city'];

    // Retrieve the house's price.
    $price = $_POST['price'];

    // Retrieve the house's bedrooms.
    $bedrooms = $_POST['bedrooms'];

    // Retrieve the house's bathrooms.
    $bathrooms = $_POST['bathrooms'];

    // Call the addHouse() method of the House object.
    // It returns true if the house is added successfully,
    // or false if the operation fails.
    if ($house->addHouse($listingNumber, $address, $city, $price, $bedrooms, $bathrooms)) {
        $message = "House added successfully!";
    } else {
        $message = "Error adding house.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>House Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">House Management System</h1>
        <p class="text-center">House Page</p>

        <div class="text-center">
            <a href="index.php" class="btn btn-primary">Dashboard</a>
            <a href="#" class="btn btn-primary">Houses</a>
        </div>

        <div class="row mt-4">
            <div class="col-md-4 mx-auto">
                <!-- Feedback message after operation -->
                <?php if ($message) echo "<div class='alert alert-info'>$message</div>"; ?>

                <h2 class="text-center mb-4">Add New House</h2>
                <form method="POST" action="house.php">
                    <div class="form-group">
                        <label>Listing Number</label>
                        <input type="text" class="form-control" name="listingNumber" placeholder="Enter listing number" required>
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" class="form-control" name="address" placeholder="Enter house address" required>
                    </div>
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" class="form-control" name="city" placeholder="Enter city" required>
                    </div>
                    <div class="form-group">
                        <label>Price</label>
                        <input type="number" class="form-control" name="price" step="0.01" placeholder="Enter price" required>
                    </div>
                    <div class="form-group">
                        <label>Bedrooms</label>
                        <input type="number" class="form-control" name="bedrooms" step="1" placeholder="Enter number of bedrooms" required>
                    </div>
                    <div class="form-group">
                        <label>Bathrooms</label>
                        <input type="number" class="form-control" name="bathrooms" step="1" placeholder="Enter number of bathrooms" required>
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </div>
            <div class="col-md-8 mx-auto">
                <h2 class="text-center mb-4">House List</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Listing Number</th>
                            <th>Address</th>
                            <th>City</th>
                            <th>Price</th>
                            <th>Bedrooms</th>
                            <th>Bathrooms</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        $houses = $house->getAllHouses();
                        while ($row = $houses->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['listing_no']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['address']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['city']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['price']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['bedrooms']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['bathrooms']) . "</td>";
                            echo "<td>
                                    <a href='edit_house.php?id=" . $row['id'] . "' class='btn btn-primary btn-sm'>Edit</a>
                                    <a href='delete_house.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick=\"return confirm('Delete this house?');\">Delete</a>
                                 </td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
