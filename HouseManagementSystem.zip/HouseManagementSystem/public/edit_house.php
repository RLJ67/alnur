<?php
// Include the House class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/House.php means go up one directory,
// then locate the House.php file inside the classes folder.
include_once __DIR__ . '/../classes/House.php';
$house = new House();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['listingNumber'], $_POST['address'], $_POST['city'], $_POST['price'], $_POST['bedrooms'], $_POST['bathrooms'])) {
    $id = $_POST['id'];
    $listingNumber = $_POST['listingNumber'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $price = $_POST['price'];
    $bedrooms = $_POST['bedrooms'];
    $bathrooms = $_POST['bathrooms'];

    // Update existing house
    if ($house->updateHouse($id, $listingNumber, $address, $city, $price, $bedrooms, $bathrooms)) {
        header("Location: house.php?message=" . urlencode("House updated successfully"));
        exit();
    } else {
        header("Location: house.php?message=" . urlencode("Error updating house"));
        exit();
    }
}

// Load the house to edit
$record = $house->getHouseById(isset($_GET['id']) ? $_GET['id'] : null);
if (!$record) {
    header("Location: house.php?message=" . urlencode("House not found"));
    exit();
}

// Pre-fill the form fields with the house's data for editing
$id = $record['id'];
        $listingNumber = $record['listing_no'];
        $address = $record['address'];
        $city = $record['city'];
        $price = $record['price'];
        $bedrooms = $record['bedrooms'];
        $bathrooms = $record['bathrooms'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>House Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">House Management System</h1>
        <h2 class="text-center mb-4">Edit House</h2>
        <div class="col-md-5 mx-auto">
            <form method="POST" action="edit_house.php">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
            <div class="form-group">
                <label>Listing Number</label>
                <input type="text" class="form-control" name="listingNumber" value="<?php echo htmlspecialchars($listingNumber); ?>" placeholder="Enter listing number" required>
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="text" class="form-control" name="address" value="<?php echo htmlspecialchars($address); ?>" placeholder="Enter house address" required>
            </div>
            <div class="form-group">
                <label>City</label>
                <input type="text" class="form-control" name="city" value="<?php echo htmlspecialchars($city); ?>" placeholder="Enter city" required>
            </div>
            <div class="form-group">
                <label>Price</label>
                <input type="number" class="form-control" name="price" value="<?php echo htmlspecialchars($price); ?>" step="0.01" placeholder="Enter price" required>
            </div>
            <div class="form-group">
                <label>Bedrooms</label>
                <input type="number" class="form-control" name="bedrooms" value="<?php echo htmlspecialchars($bedrooms); ?>" step="1" placeholder="Enter number of bedrooms" required>
            </div>
            <div class="form-group">
                <label>Bathrooms</label>
                <input type="number" class="form-control" name="bathrooms" value="<?php echo htmlspecialchars($bathrooms); ?>" step="1" placeholder="Enter number of bathrooms" required>
            </div>
                <button type="submit" class="btn btn-success">Submit</button>
                <a href="house.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
