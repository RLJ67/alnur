<?php
// Include the House class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/House.php means go up one directory,
// then locate the House.php file inside the classes folder.
include_once __DIR__ . '/../classes/House.php';
$house = new House();

$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($id) {
    // Delete the house with the given ID
    if ($house->deleteHouse($id)) {
        header("Location: house.php?message=" . urlencode("House deleted successfully"));
        exit();
    } else {
        echo "Error deleting house.";
    }
} else {
    echo "Invalid house ID.";
}

?>
