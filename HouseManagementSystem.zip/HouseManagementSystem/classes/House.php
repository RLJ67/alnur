<?php
require_once __DIR__ . '/../config/Database.php';

class House extends Database {

    public function __construct() {
        parent::__construct(); // Call parent constructor (Database)
        $this->connect();      // Establish connection automatically
    }

    // Function to add a new house to the database
    public function addHouse($listingNumber, $address, $city, $price, $bedrooms, $bathrooms) {
        try {
            $stmt = $this->conn->prepare("INSERT INTO houses (listing_no, address, city, price, bedrooms, bathrooms) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssdii", $listingNumber, $address, $city, $price, $bedrooms, $bathrooms);
            return $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            // e.g. duplicate value in a UNIQUE column
            return false;
        }
    }

    // Function to get all houses from the database
    public function getAllHouses() {
        $stmt = $this->conn->prepare("SELECT * FROM houses");
        $stmt->execute();
        return $stmt->get_result();
    }

    // Function to get a single house by ID
    public function getHouseById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM houses WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // Function to update a house's information
    public function updateHouse($id, $listingNumber, $address, $city, $price, $bedrooms, $bathrooms) {
        try {
            $stmt = $this->conn->prepare("UPDATE houses SET listing_no = ?, address = ?, city = ?, price = ?, bedrooms = ?, bathrooms = ? WHERE id = ?");
            $stmt->bind_param("sssdiii", $listingNumber, $address, $city, $price, $bedrooms, $bathrooms, $id);
            return $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            return false;
        }
    }

    // Function to delete a house from the database
    public function deleteHouse($id) {
        $stmt = $this->conn->prepare("DELETE FROM houses WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
