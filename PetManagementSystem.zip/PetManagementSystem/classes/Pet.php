<?php
require_once __DIR__ . '/../config/Database.php';

class Pet extends Database {

    public function __construct() {
        parent::__construct(); // Call parent constructor (Database)
        $this->connect();      // Establish connection automatically
    }

    // Function to add a new pet to the database
    public function addPet($name, $species, $breed, $age, $color, $ownerName) {
        try {
            $stmt = $this->conn->prepare("INSERT INTO pets (name, species, breed, age, color, owner_name) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssiss", $name, $species, $breed, $age, $color, $ownerName);
            return $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            // e.g. duplicate value in a UNIQUE column
            return false;
        }
    }

    // Function to get all pets from the database
    public function getAllPets() {
        $stmt = $this->conn->prepare("SELECT * FROM pets");
        $stmt->execute();
        return $stmt->get_result();
    }

    // Function to get a single pet by ID
    public function getPetById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM pets WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // Function to update a pet's information
    public function updatePet($id, $name, $species, $breed, $age, $color, $ownerName) {
        try {
            $stmt = $this->conn->prepare("UPDATE pets SET name = ?, species = ?, breed = ?, age = ?, color = ?, owner_name = ? WHERE id = ?");
            $stmt->bind_param("sssissi", $name, $species, $breed, $age, $color, $ownerName, $id);
            return $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            return false;
        }
    }

    // Function to delete a pet from the database
    public function deletePet($id) {
        $stmt = $this->conn->prepare("DELETE FROM pets WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
