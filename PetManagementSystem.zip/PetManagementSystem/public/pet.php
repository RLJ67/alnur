<?php

// Include the Pet class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/Pet.php means go up one directory,
// then locate the Pet.php file inside the classes folder.
include_once __DIR__ . '/../classes/Pet.php';

// Create an object (instance) of the Pet class.
// This object will be used to call the addPet() method.
$pet = new Pet();

// Initialize an empty message variable.
// This will store the result of the pet registration process.
$message = '';

// Show a message passed from the edit/delete pages (if any).
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

// Check whether the submitted request uses the POST method.
// Also check whether all required form fields are present
// in the $_POST array.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'], $_POST['species'], $_POST['breed'], $_POST['age'], $_POST['color'], $_POST['ownerName'])) {

    // Retrieve the pet's pet name.
    $name = $_POST['name'];

    // Retrieve the pet's species.
    $species = $_POST['species'];

    // Retrieve the pet's breed.
    $breed = $_POST['breed'];

    // Retrieve the pet's age (years).
    $age = $_POST['age'];

    // Retrieve the pet's color.
    $color = $_POST['color'];

    // Retrieve the pet's owner name.
    $ownerName = $_POST['ownerName'];

    // Call the addPet() method of the Pet object.
    // It returns true if the pet is added successfully,
    // or false if the operation fails.
    if ($pet->addPet($name, $species, $breed, $age, $color, $ownerName)) {
        $message = "Pet added successfully!";
    } else {
        $message = "Error adding pet.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Pet Management System</h1>
        <p class="text-center">Pet Page</p>

        <div class="text-center">
            <a href="index.php" class="btn btn-primary">Dashboard</a>
            <a href="#" class="btn btn-primary">Pets</a>
        </div>

        <div class="row mt-4">
            <div class="col-md-4 mx-auto">
                <!-- Feedback message after operation -->
                <?php if ($message) echo "<div class='alert alert-info'>$message</div>"; ?>

                <h2 class="text-center mb-4">Add New Pet</h2>
                <form method="POST" action="pet.php">
                    <div class="form-group">
                        <label>Pet Name</label>
                        <input type="text" class="form-control" name="name" placeholder="Enter pet name" required>
                    </div>
                    <div class="form-group">
                        <label>Species</label>
                        <input type="text" class="form-control" name="species" placeholder="Enter species (e.g. Dog, Cat)" required>
                    </div>
                    <div class="form-group">
                        <label>Breed</label>
                        <input type="text" class="form-control" name="breed" placeholder="Enter breed" required>
                    </div>
                    <div class="form-group">
                        <label>Age (years)</label>
                        <input type="number" class="form-control" name="age" step="1" placeholder="Enter age" required>
                    </div>
                    <div class="form-group">
                        <label>Color</label>
                        <input type="text" class="form-control" name="color" placeholder="Enter color" required>
                    </div>
                    <div class="form-group">
                        <label>Owner Name</label>
                        <input type="text" class="form-control" name="ownerName" placeholder="Enter owner name" required>
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </div>
            <div class="col-md-8 mx-auto">
                <h2 class="text-center mb-4">Pet List</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Pet Name</th>
                            <th>Species</th>
                            <th>Breed</th>
                            <th>Age (years)</th>
                            <th>Color</th>
                            <th>Owner Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        $pets = $pet->getAllPets();
                        while ($row = $pets->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['species']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['breed']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['age']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['color']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['owner_name']) . "</td>";
                            echo "<td>
                                    <a href='edit_pet.php?id=" . $row['id'] . "' class='btn btn-primary btn-sm'>Edit</a>
                                    <a href='delete_pet.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick=\"return confirm('Delete this pet?');\">Delete</a>
                                 </td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
