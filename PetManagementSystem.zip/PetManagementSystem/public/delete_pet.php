<?php
// Include the Pet class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/Pet.php means go up one directory,
// then locate the Pet.php file inside the classes folder.
include_once __DIR__ . '/../classes/Pet.php';
$pet = new Pet();

$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($id) {
    // Delete the pet with the given ID
    if ($pet->deletePet($id)) {
        header("Location: pet.php?message=" . urlencode("Pet deleted successfully"));
        exit();
    } else {
        echo "Error deleting pet.";
    }
} else {
    echo "Invalid pet ID.";
}

?>
