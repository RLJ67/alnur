<?php
// Include the Pet class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/Pet.php means go up one directory,
// then locate the Pet.php file inside the classes folder.
include_once __DIR__ . '/../classes/Pet.php';
$pet = new Pet();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['name'], $_POST['species'], $_POST['breed'], $_POST['age'], $_POST['color'], $_POST['ownerName'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $species = $_POST['species'];
    $breed = $_POST['breed'];
    $age = $_POST['age'];
    $color = $_POST['color'];
    $ownerName = $_POST['ownerName'];

    // Update existing pet
    if ($pet->updatePet($id, $name, $species, $breed, $age, $color, $ownerName)) {
        header("Location: pet.php?message=" . urlencode("Pet updated successfully"));
        exit();
    } else {
        header("Location: pet.php?message=" . urlencode("Error updating pet"));
        exit();
    }
}

// Load the pet to edit
$record = $pet->getPetById(isset($_GET['id']) ? $_GET['id'] : null);
if (!$record) {
    header("Location: pet.php?message=" . urlencode("Pet not found"));
    exit();
}

// Pre-fill the form fields with the pet's data for editing
$id = $record['id'];
        $name = $record['name'];
        $species = $record['species'];
        $breed = $record['breed'];
        $age = $record['age'];
        $color = $record['color'];
        $ownerName = $record['owner_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Pet Management System</h1>
        <h2 class="text-center mb-4">Edit Pet</h2>
        <div class="col-md-5 mx-auto">
            <form method="POST" action="edit_pet.php">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
            <div class="form-group">
                <label>Pet Name</label>
                <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($name); ?>" placeholder="Enter pet name" required>
            </div>
            <div class="form-group">
                <label>Species</label>
                <input type="text" class="form-control" name="species" value="<?php echo htmlspecialchars($species); ?>" placeholder="Enter species (e.g. Dog, Cat)" required>
            </div>
            <div class="form-group">
                <label>Breed</label>
                <input type="text" class="form-control" name="breed" value="<?php echo htmlspecialchars($breed); ?>" placeholder="Enter breed" required>
            </div>
            <div class="form-group">
                <label>Age (years)</label>
                <input type="number" class="form-control" name="age" value="<?php echo htmlspecialchars($age); ?>" step="1" placeholder="Enter age" required>
            </div>
            <div class="form-group">
                <label>Color</label>
                <input type="text" class="form-control" name="color" value="<?php echo htmlspecialchars($color); ?>" placeholder="Enter color" required>
            </div>
            <div class="form-group">
                <label>Owner Name</label>
                <input type="text" class="form-control" name="ownerName" value="<?php echo htmlspecialchars($ownerName); ?>" placeholder="Enter owner name" required>
            </div>
                <button type="submit" class="btn btn-success">Submit</button>
                <a href="pet.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
