<?php
require_once __DIR__ . '/../config/Database.php';

class Customer extends Database {

    public function __construct() {
        parent::__construct(); // Call parent constructor (Database)
        $this->connect();      // Establish connection automatically
    }

    // Function to add a new customer to the database
    public function addCustomer($customerNumber, $name, $email, $phone, $address, $birthdate) {
        try {
            $stmt = $this->conn->prepare("INSERT INTO customers (customer_no, name, email, phone, address, birthdate) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", $customerNumber, $name, $email, $phone, $address, $birthdate);
            return $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            // e.g. duplicate value in a UNIQUE column
            return false;
        }
    }

    // Function to get all customers from the database
    public function getAllCustomers() {
        $stmt = $this->conn->prepare("SELECT * FROM customers");
        $stmt->execute();
        return $stmt->get_result();
    }

    // Function to get a single customer by ID
    public function getCustomerById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM customers WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // Function to update a customer's information
    public function updateCustomer($id, $customerNumber, $name, $email, $phone, $address, $birthdate) {
        try {
            $stmt = $this->conn->prepare("UPDATE customers SET customer_no = ?, name = ?, email = ?, phone = ?, address = ?, birthdate = ? WHERE id = ?");
            $stmt->bind_param("ssssssi", $customerNumber, $name, $email, $phone, $address, $birthdate, $id);
            return $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            return false;
        }
    }

    // Function to delete a customer from the database
    public function deleteCustomer($id) {
        $stmt = $this->conn->prepare("DELETE FROM customers WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
