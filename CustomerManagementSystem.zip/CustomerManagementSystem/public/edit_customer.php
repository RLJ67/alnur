<?php
// Include the Customer class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/Customer.php means go up one directory,
// then locate the Customer.php file inside the classes folder.
include_once __DIR__ . '/../classes/Customer.php';
$customer = new Customer();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['customerNumber'], $_POST['name'], $_POST['email'], $_POST['phone'], $_POST['address'], $_POST['birthdate'])) {
    $id = $_POST['id'];
    $customerNumber = $_POST['customerNumber'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $birthdate = $_POST['birthdate'];

    // Update existing customer
    if ($customer->updateCustomer($id, $customerNumber, $name, $email, $phone, $address, $birthdate)) {
        header("Location: customer.php?message=" . urlencode("Customer updated successfully"));
        exit();
    } else {
        header("Location: customer.php?message=" . urlencode("Error updating customer"));
        exit();
    }
}

// Load the customer to edit
$record = $customer->getCustomerById(isset($_GET['id']) ? $_GET['id'] : null);
if (!$record) {
    header("Location: customer.php?message=" . urlencode("Customer not found"));
    exit();
}

// Pre-fill the form fields with the customer's data for editing
$id = $record['id'];
        $customerNumber = $record['customer_no'];
        $name = $record['name'];
        $email = $record['email'];
        $phone = $record['phone'];
        $address = $record['address'];
        $birthdate = $record['birthdate'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Customer Management System</h1>
        <h2 class="text-center mb-4">Edit Customer</h2>
        <div class="col-md-5 mx-auto">
            <form method="POST" action="edit_customer.php">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
            <div class="form-group">
                <label>Customer Number</label>
                <input type="text" class="form-control" name="customerNumber" value="<?php echo htmlspecialchars($customerNumber); ?>" placeholder="Enter customer number" required>
            </div>
            <div class="form-group">
                <label>Customer Name</label>
                <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($name); ?>" placeholder="Enter customer name" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($email); ?>" placeholder="Enter customer email" required>
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($phone); ?>" placeholder="Enter customer phone" required>
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="text" class="form-control" name="address" value="<?php echo htmlspecialchars($address); ?>" placeholder="Enter customer address" required>
            </div>
            <div class="form-group">
                <label>Birthdate</label>
                <input type="date" class="form-control" name="birthdate" value="<?php echo htmlspecialchars($birthdate); ?>" required>
            </div>
                <button type="submit" class="btn btn-success">Submit</button>
                <a href="customer.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
