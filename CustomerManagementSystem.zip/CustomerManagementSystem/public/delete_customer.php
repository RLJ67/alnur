<?php
// Include the Customer class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/Customer.php means go up one directory,
// then locate the Customer.php file inside the classes folder.
include_once __DIR__ . '/../classes/Customer.php';
$customer = new Customer();

$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($id) {
    // Delete the customer with the given ID
    if ($customer->deleteCustomer($id)) {
        header("Location: customer.php?message=" . urlencode("Customer deleted successfully"));
        exit();
    } else {
        echo "Error deleting customer.";
    }
} else {
    echo "Invalid customer ID.";
}

?>
