<?php

// Include the Customer class file.
// __DIR__ refers to the directory of the current PHP file.
// ../classes/Customer.php means go up one directory,
// then locate the Customer.php file inside the classes folder.
include_once __DIR__ . '/../classes/Customer.php';

// Create an object (instance) of the Customer class.
// This object will be used to call the addCustomer() method.
$customer = new Customer();

// Initialize an empty message variable.
// This will store the result of the customer registration process.
$message = '';

// Show a message passed from the edit/delete pages (if any).
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

// Check whether the submitted request uses the POST method.
// Also check whether all required form fields are present
// in the $_POST array.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['customerNumber'], $_POST['name'], $_POST['email'], $_POST['phone'], $_POST['address'], $_POST['birthdate'])) {

    // Retrieve the customer's customer number.
    $customerNumber = $_POST['customerNumber'];

    // Retrieve the customer's customer name.
    $name = $_POST['name'];

    // Retrieve the customer's email.
    $email = $_POST['email'];

    // Retrieve the customer's phone.
    $phone = $_POST['phone'];

    // Retrieve the customer's address.
    $address = $_POST['address'];

    // Retrieve the customer's birthdate.
    $birthdate = $_POST['birthdate'];

    // Call the addCustomer() method of the Customer object.
    // It returns true if the customer is added successfully,
    // or false if the operation fails.
    if ($customer->addCustomer($customerNumber, $name, $email, $phone, $address, $birthdate)) {
        $message = "Customer added successfully!";
    } else {
        $message = "Error adding customer.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Customer Management System</h1>
        <p class="text-center">Customer Page</p>

        <div class="text-center">
            <a href="index.php" class="btn btn-primary">Dashboard</a>
            <a href="#" class="btn btn-primary">Customers</a>
        </div>

        <div class="row mt-4">
            <div class="col-md-4 mx-auto">
                <!-- Feedback message after operation -->
                <?php if ($message) echo "<div class='alert alert-info'>$message</div>"; ?>

                <h2 class="text-center mb-4">Add New Customer</h2>
                <form method="POST" action="customer.php">
                    <div class="form-group">
                        <label>Customer Number</label>
                        <input type="text" class="form-control" name="customerNumber" placeholder="Enter customer number" required>
                    </div>
                    <div class="form-group">
                        <label>Customer Name</label>
                        <input type="text" class="form-control" name="name" placeholder="Enter customer name" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" name="email" placeholder="Enter customer email" required>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" class="form-control" name="phone" placeholder="Enter customer phone" required>
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" class="form-control" name="address" placeholder="Enter customer address" required>
                    </div>
                    <div class="form-group">
                        <label>Birthdate</label>
                        <input type="date" class="form-control" name="birthdate" required>
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </div>
            <div class="col-md-8 mx-auto">
                <h2 class="text-center mb-4">Customer List</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Customer Number</th>
                            <th>Customer Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Birthdate</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        $customers = $customer->getAllCustomers();
                        while ($row = $customers->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['customer_no']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['phone']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['address']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['birthdate']) . "</td>";
                            echo "<td>
                                    <a href='edit_customer.php?id=" . $row['id'] . "' class='btn btn-primary btn-sm'>Edit</a>
                                    <a href='delete_customer.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick=\"return confirm('Delete this customer?');\">Delete</a>
                                 </td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
